// Simple health check handler
exports.health = async (event, context) => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS'
    },
    body: JSON.stringify({
      status: 'OK',
      message: 'PermitPro API is running',
      timestamp: new Date().toISOString()
    })
  };
};

// Simple API handler
exports.api = async (event, context) => {
  const path = event.path;
  const method = event.httpMethod;
  
  // Health check
  if (path === '/health' || path === '/api/health') {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        status: 'OK',
        message: 'PermitPro API is running',
        timestamp: new Date().toISOString()
      })
    };
  }
  
  // Packages endpoint
  if (path === '/api/packages' && method === 'GET') {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        packages: [
          {
            id: 'PKG-001',
            customerName: 'Demo Customer',
            propertyAddress: '123 Demo St, Demo City, FL',
            county: 'Demo County',
            status: 'Draft',
            createdAt: new Date().toISOString()
          }
        ]
      })
    };
  }
  
  // Login endpoint
  if (path === '/api/auth/login' && method === 'GET') {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({
        user: {
          id: '1',
          name: 'Demo User',
          email: 'demo@example.com',
          role: 'Admin'
        },
        token: 'demo-token-123'
      })
    };
  }
  
  // Default response
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({
      message: 'PermitPro API',
      path: path,
      method: method,
      endpoints: [
        'GET /health',
        'GET /api/health',
        'GET /api/packages',
        'GET /api/auth/login'
      ]
    })
  };
};